<?php

$start = "dW5jaGVrYXFzaGFAZ21haWwuY29t";

$play = base64_decode($start);

?>